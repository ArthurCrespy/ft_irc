/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Channel_utils.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdegluai <jdegluai@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/24 09:46:27 by acrespy           #+#    #+#             */
/*   Updated: 2024/06/10 14:48:36 by jdegluai         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/ft_irc.h"


bool	Channel::isInvited(Client *user) const {
	return (std::find(this->_inviteList.begin(), this->_inviteList.end(), user->getNickname()) != this->_inviteList.end());
}

void Channel::setTopic(std::string const &topic)
{
	if (topic.empty())
	{
		_channel_topic = "No topic is set";
		_channel_topic_set = false;
	}
	else
	{
		_channel_topic = topic;
		_channel_topic_set = true;
	}
}

void Channel::setTopicSet(bool set)
{
	_channel_topic_set = set;
}

void Channel::setTopicRestriction(bool restrict)
{
	_channel_topic_restrict = restrict;
}

void Channel::setPassword(std::string const &password)
{
	if (password.empty())
	{
		// _channel_password = "";
		_channel_password_restrict = false;
	}
	else
	{
		_channel_password = password;
		_channel_password_restrict = true;
	}
}

bool	Channel::hasMode(char mode) const {
	return (std::find(this->_modes.begin(), this->_modes.end(), mode) != this->_modes.end());
}

void Channel::setPasswordRestriction(bool restrict)
{
	_channel_password_restrict = restrict;
}

void Channel::setLimit(int limit)
{
	_channel_limit = limit;
}

void Channel::setInviteOnly(bool io)
{
	_channel_invite_only = io;
}

void Channel::setOwner(Client *owner)
{
	_owner = owner;
}

std::string Channel::getName(void) const
{
	return (_channel_name);
}

std::string Channel::getTopic(void) const
{
	return (_channel_topic);
}

bool Channel::getTopicSet(void) const
{
	return (_channel_topic_set);
}

bool Channel::getTopicRestriction(void) const
{
	return (_channel_topic_restrict);
}

std::string Channel::getPassword(void) const
{
	return (_channel_password);
}

bool Channel::getPasswordRestriction(void) const
{
	return (_channel_password_restrict);
}

int Channel::getLimit(void) const
{
	return (_channel_limit);
}

bool Channel::getInviteOnly(void) const
{
	return (_channel_invite_only);
}

t_members Channel::getMembers(void) const
{
	return (_channel_members);
}

t_members Channel::getAdmins(void) const
{
	return (_channel_admins);
}

void Channel::addMember(Client *member)
{
	_channel_members.insert(std::make_pair(member->getNickname(), member));
}

void Channel::removeMember(Client *member)
{
	it_members it = _channel_members.find(member->getNickname());
	if (it != _channel_members.end())
	{
		removeAdmin(member);
		if (_channel_admins.empty())
			addAdmin(_channel_members.begin()->second);
		_channel_members.erase(it);
	}

}

void Channel::removeMember(std::string const &member)
{
	it_members it = _channel_members.find(member);
	if (it != _channel_members.end())
	{
		removeAdmin((*it).second);
		if (_channel_admins.empty())
			addAdmin(_channel_members.begin()->second);
		_channel_members.erase(it);
	}
}

void Channel::addAdmin(Client *op)
{
	op->ft_send(op->getFd(), RPL_CHANNELMODEIS(op->getNickname(), _channel_name, "+o ", op->getNickname()), 0);
	_channel_admins.insert(std::make_pair(op->getNickname(), op));
}

void Channel::removeAdmin(Client *op)
{
	it_members it = _channel_members.find(op->getNickname());
	if (it != _channel_admins.end())
	{
		(*it).second->ft_send((*it).second->getFd(), RPL_CHANNELMODEIS((*it).second->getNickname(), _channel_name, "-o ", op->getNickname()), 0);
		_channel_admins.erase(it);
	}
}

void Channel::removeAdmin(std::string const &op)
{
	it_members it = _channel_members.find(op);
	if (it != _channel_admins.end())
	{
		(*it).second->ft_send((*it).second->getFd(), RPL_CHANNELMODEIS((*it).second->getNickname(), _channel_name, "-o ", op), 0);
		_channel_admins.erase(it);
	}
}

void Channel::broadcast(std::string const &msg)
{
	// for (it_members it = _channel_members.begin(); it != _channel_members.end(); ++it)
	// {
	// 	std::cout << "ici" << std::endl;
	// 	std::cout << (*it).second->getNickname();
	// 	if (it != --_channel_members.end())
	// 		std::cout << ", ";
	// }
	// std::cout << std::endl;

	for (it_members it = _channel_members.begin(); it != _channel_members.end(); it++)
		(*it).second->ft_send((*it).second->getFd(), msg, 0);
}
